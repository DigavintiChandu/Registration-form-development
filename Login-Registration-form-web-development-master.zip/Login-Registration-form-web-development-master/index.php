<?php
require 'config/config.php';

$query = mysqli_query($con, "INSERT INTO test VALUES('','Soham')");
?>

<!DOCTYPE html>
<html>
<head>
	<title>SayHello</title>
</head>
<body>
	Hello, SD2000 here!!!
</body>
</html>