# Login Registration form template

A great GUI based login,registration form for any web portal, by using PHP,CSS,JQuery,Javascript and MySql
